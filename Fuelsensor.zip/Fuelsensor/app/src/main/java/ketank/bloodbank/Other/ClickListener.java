package ketank.bloodbank.Other;

import android.view.View;

/**
 * Created by Ketan-PC on 12/26/2017.
 */

public interface ClickListener {
    void onClick(View view, int position);

    void onLongClick(View view, int position);
}
